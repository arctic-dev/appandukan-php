@extends('layouts.superadmin')
@section('content')
<style>
body
{
	    color: #401724;
}
</style>
<div class="form-group" style="display:none;">
                <label class="col-sm-3 control-label">Fullscreen Textarea</label>
                <div class="col-sm-6">
                    <textarea class="form-control fullscreen"></textarea>
                </div>
            </div>
<div id="page-content">
  <div id='wrap'>
    <div id="page-heading">
      <ol class="breadcrumb">
        <li><a href="<?php echo url('superadmin/dashboard');?>">Superadmin</a></li>
        <li>Add Pan Card ( 49A Form )</li>
      </ol>
      <h1>Add Pan Card ( 49A Form )</h1>
      <div class="options">
        <div class="btn-toolbar">
          <div class="btn-group hidden-xs"> <a href='#' class="btn btn-default dropdown-toggle" data-toggle='dropdown'><i class="fa fa-cloud-download"></i><span class="hidden-xs hidden-sm hidden-md"> Export as</span> <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="#">Text File (*.txt)</a></li>
              <li><a href="#">Excel File (*.xlsx)</a></li>
              <li><a href="#">PDF File (*.pdf)</a></li>
            </ul>
          </div>
          <a href="#" class="btn btn-default hidden-xs"><i class="fa fa-cog"></i></a> </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="panel panel-primary"> {{ Form::open(array('url'=>'superadmin/creditdebit/store', 'class'=>'form-horizontal')) }}
            <?php if(Session::has('failure')){ ?>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              {{Session::get('failure')}} </div>
            <?php } ?>
            <?php if(Session::has('sucess')){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              {{Session::get('sucess')}} </div>
            <?php } ?>
            
            <div class="col-md-6">
            <div class="col-md-12">
            <div class="panel-heading">
              <h4>Pan Card ( 49A Form ) Name Details</h4>
            </div>
            <div class="panel-body">
            
              <div class="form-group">
                <label for="fieldname" class="col-md-3 control-label">Please select Title</label>
                <div class="col-md-6">
                  <select class="form-control" name="name">
                    <option>Shri</option>
                    <option>Smt</option>
                    <option>Kumari</option>
                    <option>M/s</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">First Name</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="firstname" required="required" placeholder="First Name">
                </div>
              </div>
               <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">Last Name</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="lastname" required="required" placeholder="Last Name">
                </div>
              </div>
              <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">Middle Name</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="middlename" required="required" placeholder="Middle Name">
                </div>
              </div>
            </div>
            </div>
             <div class="col-md-12" style="margin-top:20px;">
            <div class="panel-heading">
              <h4>Card and Date Details</h4>
            </div>
            <div class="panel-body">
            <legend style="font-size:16px;">Abbreviation of the Above name, as you would like it, to be printed on the PAN Card</legend>
            <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label"></label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="lastname" required="required" placeholder="Last Name">
                </div>
              </div>
            <legend style="font-size:16px;">Date of Birth/Incorporation/Agreement/Partnership or Trust Deed/Formation of Body of Individuals or Association of Persons</legend>
              
              <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label"></label>
                <div class="col-sm-6">
                    
                        <input type="text" class="form-control" id="datepicker">
                      
                    
                </div>
              </div>
               
              
            </div>
            </div>
            </div>
            <div class="col-md-6">
            <div class="col-md-12">
            <div class="panel-heading">
              <h4>Pan Card ( 49A Form ) Name Details</h4>
            </div>
            <div class="panel-body">
            
              <legend style="font-size:16px;">Father's Name (Only 'Individual' applicants: Even married women should fill in father's name only)</legend>
              <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">First Name</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="firstname" required="required" placeholder="First Name">
                </div>
              </div>
              <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">Last Name</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="lastname" required="required" placeholder="Last Name">
                </div>
              </div> 
              <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">Middle Name</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="middlename" required="required" placeholder="Middle Name">
                </div>
              </div>
            </div>
            </div>
             <div class="col-md-12" style="margin-top:20px;">
            <div class="panel-heading">
              <h4>Telephone number and Email ID details</h4>
            </div>
            <div class="panel-body">
            
            <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">Country Code</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="lastname" required="required" placeholder="Country Code">
                </div>
              </div>
              
              <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">Area/STD Code</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="areacode" required="required" placeholder="Area/STD Code">
                </div>
              </div>
              
              <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">Telephone/Mobile number</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="lastname" required="required" placeholder="Telephone/Mobile number">
                </div>
              </div>
          
              
              <div class="form-group">
                <label for="fieldurl" class="col-md-3 control-label">Email Id</label>
                <div class="col-md-6">
                  <input  class="form-control"  type="text" name="firstname" required="required" placeholder="Email Id" id="date">
                </div>
              </div>
               
              
            </div>
            </div>
            </div>
            
            <div class="col-md-12" style="margin-top:20px;">
            <div class="col-md-12">
            
            <div class="panel-footer">
              <div class="row">
                <div class="col-sm-6 col-sm-offset-3">
                  <div class="btn-toolbar">
                    <button class="btn-primary btn">Submit</button>
                    <button class="btn-default btn">Cancel</button>
                  </div>
                </div>
              </div>
              </div>
            </div>
            </div>
            </form>
           
          </div>
        </div>
      </div>
    </div>
    <!-- container --> 
  </div>
  <!--wrap --> 
</div>
<!-- page-content --> 

@stop